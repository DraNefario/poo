import java.util.Scanner;

 class Area {
    public float base;
    public float altura;

    public float triangulo(float base, float altura){
        return base * altura / 2;
    }
    public float quadrado(float base, float altura){
        return base * altura;
    }


}
