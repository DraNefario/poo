import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Area area = new Area();


        System.out.println("**** MENU ****");
        System.out.println("(1) Área de um triângulo");
        System.out.println("(2) Área de um quadrado");
        System.out.println("(9) Sair");

        System.out.println("Escolha uma opçao: ");
        int opcao = sc.nextInt();
        sc.nextLine();

        if (opcao == 1) {
            System.out.println("Base: ");
            float base = sc.nextFloat();
            sc.nextLine();

            System.out.println("Altura: ");
            float altura = sc.nextFloat();
            sc.nextLine();

            float resultadoTriangulo = area.triangulo(base, altura);
            System.out.println("Área do triângulo: " + resultadoTriangulo);
        }

        else if (opcao == 2) {
            System.out.println("Base: ");
            float baseQuadrado = sc.nextFloat();
            sc.nextLine();

            System.out.println("Altura: ");
            float alturaQuadrado = sc.nextFloat();
            sc.nextLine();

            float resultadoQuadrado = area.quadrado(baseQuadrado, alturaQuadrado);
            System.out.println("Área do quadrado: " + resultadoQuadrado);
        }

        else if (opcao == 9){
            System.out.println("programa encerrado");
        }
        else {
            System.out.println("Opção invalida");
        }
    }

}
